#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
    float distance;
    double mass;
    distance=1.495979E11;
    mass=1.989E30;
    cout<<"The Sun is "<<distance<<" meters away."
         <<endl;
    cout<<"The Sun\'s mass is "<<mass<<" kilograms."
         <<endl;
return 0; }
