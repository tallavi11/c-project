#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <string>

using namespace std;

float CalcSales(float);
float StateTaxAmount(float);
float CountyTaxAmount(float);
void Output(float);

#endif
