#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <functions.h>

using namespace std;

int main(int argc, char **argv)
{
	float postTax;
	cout<<"Enter the post-tax amount: ";
	cin>>postTax;
	Output(postTax);
	return 0;
}
